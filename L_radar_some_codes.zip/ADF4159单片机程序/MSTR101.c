#include <c8051f020.h>
#define  uint8_t  unsigned int
#define  uint32_t  unsigned long int
	
sbit PLL_LE = P0^0;
sbit PLL_CLK = P0^1;
sbit PLL_DATA = P0^2;

sbit gain_LE1 = P3^0;
sbit gain_CLK1 = P3^1;
sbit gain_DATA1 = P3^2;
sbit gain1_Pul1 = P3^3;
sbit gain1_Pul2 = P3^4;

sbit gain_LE2 = P3^5;
sbit gain_CLK2 = P3^6;
sbit gain_DATA2 = P3^7;
sbit gain2_Pul1 = P2^0;
sbit gain2_Pul2 = P2^1;

void Watchdog_Init(void);
void OSCILLATOR_Init (void);           
void PORT_Init (void);

// Watchdog_Init

 void Watchdog_Init(void)
{
	WDTCN = 0xde;                       // disable watchdog timer
   	WDTCN = 0xad;                       // disable watchdog timer
}
//-----------------------------------------------------------------------------
// OSCILLATOR_Init
//-----------------------------------------------------------------------------

void OSCILLATOR_Init (void)
{
    int i;                         	// delay counter
	OSCXCN = 0x67;                 	// start external oscillator with 22.1184MHz crystal
	for (i=0; i < 256; i++) ;      	// XTLVLD blanking interval (>1ms)
	while (!(OSCXCN & 0x80)) ;     	// Wait for crystal osc. to settle
   	OSCICN = 0x88;                 	// select external oscillator as SYSCLK source and enable missing clock detector
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------

void PORT_Init (void)
{
   XBR2    = 0x40;                     // Enable crossbar and enable weak pull-ups
   P0MDOUT = 0xFF;                     // P0 is push pull
   P1MDOUT = 0xFF;                     // P1 is push pull
   P2MDOUT = 0xFF;                     // P2 is push pull
   P3MDOUT = 0x00;                     // P3 is drain open
   P74OUT = 0xFF;
   P0 = 0x00;
   P1 = 0x00;
   P2 = 0x00;
   P3 = 0xFF;
   P4 = 0x00;
   P5 = 0x00;
   P6 = 0x00;
   P7 = 0x00;
}

void delay (int length)
{
	int i;
	i = length * 200 ;
	while (i > 0)
	i--;
}


void gain1(unsigned	int DATA)
{
	unsigned	int	ValueToWrite = DATA;
  unsigned	int	i = 0;
	unsigned	int	j = 0;
	gain_CLK1 = 0;
	gain_LE1 = 0;
	gain1_Pul1 = 0;
	gain1_Pul2 = 0;
	delay(1);
		for(j=0; j<6; j++)
		{
			if(0x20 == (ValueToWrite & 0x20))
			{
				gain_DATA1 = 1;	  //Send one to SDO pin
			}
			else
			{
				gain_DATA1 = 0;	  //Send zero to SDO pin
			}
			delay(1);
			gain_CLK1 = 1;
			delay(1);
			ValueToWrite <<= 1;	//Rotate data
			gain_CLK1 = 0;
		}
	gain_DATA1 = 0;
	delay(1);
	gain_LE1 = 1;
	delay(1);
	gain_LE1 = 0;
}

void gain2(unsigned	int DATA)
{
	unsigned	int	ValueToWrite = DATA;
  unsigned	int	i = 0;
	unsigned	int	j = 0;
	gain_CLK2 = 0;
	gain_LE2 = 0;
	gain2_Pul1 = 0;
	gain2_Pul2 = 0;
	delay(1);
		for(j=0; j<6; j++)
		{
			if(0x20 == (ValueToWrite & 0x20))
			{
				gain_DATA2 = 1;	  //Send one to SDO pin
			}
			else
			{
				gain_DATA2 = 0;	  //Send zero to SDO pin
			}
			delay(1);
			gain_CLK2 = 1;
			delay(1);
			ValueToWrite <<= 1;	//Rotate data
			gain_CLK2 = 0;
		}
	gain_DATA2 = 0;
	delay(1);
	gain_LE2 = 1;
	delay(1);
	gain_LE2 = 0;
}

void WriteToADF4159(unsigned long int DATA)
{
	unsigned long int	ValueToWrite;
  unsigned	char	i = 0;
	PLL_CLK = 0;
	PLL_LE = 0;
	delay(1);
	ValueToWrite = DATA;
		for(i=0; i<32; i++)
		{
			if(0x80000000 == (ValueToWrite & 0x80000000))
			{
				PLL_DATA = 1;	  //Send one to SDO pin
			}
			else
			{
				PLL_DATA = 0;	  //Send zero to SDO pin
			}
			delay(1);
			PLL_CLK = 1;
			delay(1);
			ValueToWrite <<= 1;	//Rotate data
			PLL_CLK = 0;
		}
	PLL_DATA = 0;
	delay(1);
	PLL_LE = 1;
	delay(1);
	PLL_LE = 0;
}

void main()
{
	Watchdog_Init();
  PORT_Init();                    
  OSCILLATOR_Init ();
	
//	WriteToADF4159(0x00080007); //reg 7
//	
//	WriteToADF4159(0x00001F46);//reg 6
//	WriteToADF4159(0x00801F46);
//	
//	WriteToADF4159(0x01101F45);//reg 5
//	WriteToADF4159(0x01901F45);
//	
//	WriteToADF4159(0x00180084);//reg 4
//	WriteToADF4159(0x001800C4);
//	
//	WriteToADF4159(0x00000443);//reg 3
//	WriteToADF4159(0x00608012);//reg 2
//	WriteToADF4159(0x00000001);//reg 1
//	WriteToADF4159(0xB03C0000);//reg 0
	
//good	
//	WriteToADF4159(0x00000007); //reg 7
//	
//	WriteToADF4159(0x00001F46);//reg 6
//	WriteToADF4159(0x00800006);
//	
//	WriteToADF4159(0x00481F45);//reg 5
//	WriteToADF4159(0x00800005);
//	
//	WriteToADF4159(0x00180004);//reg 4
//	WriteToADF4159(0x00180144);
//	
//	WriteToADF4159(0x00430083);//reg 3
//	WriteToADF4159(0x0020800A);//reg 2
//	WriteToADF4159(0x00000001);//reg 1
//	WriteToADF4159(0xB03C0000);//reg 0

	WriteToADF4159(0x00000007); //reg 7
	
	WriteToADF4159(0x00001F46);//reg 6
	WriteToADF4159(0x00800006);
	
	WriteToADF4159(0x00481F45);//reg 5
	WriteToADF4159(0x00800005);
	
	WriteToADF4159(0x00180284);//reg 4
	WriteToADF4159(0x00180144);
	
	WriteToADF4159(0x00430083);//reg 3
	WriteToADF4159(0x0020800A);//reg 2
	WriteToADF4159(0x00000001);//reg 1
	WriteToADF4159(0xB03A0000);//reg 0

	
	gain1(0x00);//quan shi 1,shuai jian zui da,0x3f
	gain2(0x1;0);//
	while(1);
}
